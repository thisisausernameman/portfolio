function setup() {
  createCanvas(400, 400);
}
var y = 60;
var x = 60;
function draw() {
  background(220);
  
  ellipse(60,60,x,y);
  
  x = x+1;
  y = y+1;
  
}